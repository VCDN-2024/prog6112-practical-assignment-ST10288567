/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapplication;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Main class for the Student Management Application.
 * Handles the menu and interactions with the user.
 * 
 * @author Darsh Somayi
 */
public class STUDENTMANAGEMENTAPPLICATION {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Create a scanner for user input
        StudentManagement sm = new StudentManagement(); // Instantiate the StudentManagement class

        // Infinite loop to keep the application running until the user decides to exit
        while (true) {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            String input = scanner.nextLine();
            
            // If the user input is not "1", exit the application
            if (!input.equals("1")) {
                sm.exitStudentApplication();
            }
 // Display the menu options
            System.out.println("Please select one of the following menu items:");
            System.out.println(" 1. Capture a new student.");
            System.out.println(" 2. Search for a student.");
            System.out.println(" 3. Delete a student.");
            System.out.println(" 4. Print student report.");
            System.out.println(" 5. Exit Application");


            // Read the user's menu choice
            String choice = scanner.nextLine();

            // Switch case to handle different menu options
            switch (choice) {
                case "1":
                    sm.saveStudent(); // Capture a new student
                    break;
                case "2":
                    sm.searchStudent(); // Search for a student
                    break;
                case "3":
                    sm.deleteStudent(); // Delete a student
                    break;
                case "4":
                    sm.studentReport(); // Print the student report
                    break;
                case "5":
                    sm.exitStudentApplication(); // Exit the application
                    break;
                default:
                    System.out.println("Invalid selection, please try again."); // Handle invalid input
            }
        }
    }
}

// Class to represent a Student entity
class Student {
    private String studentId; // Unique ID of the student
    private String name; // Name of the student
    private int age; // Age of the student
    private String email; // Email address of the student
    private String course; // Course the student is enrolled in

    // Constructor to initialize a new student
    public Student(String studentId, String name, int age, String email, String course) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters for accessing student details
    public String getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    // Override toString method to provide a string representation of the student
    @Override
    public String toString() {
        return "STUDENT ID: " + studentId + "\n" +
               "STUDENT NAME: " + name + "\n" +
               "STUDENT AGE: " + age + "\n" +
               "STUDENT EMAIL: " + email + "\n" +
               "STUDENT COURSE: " + course + "\n";
    }
}

// Class to manage student operations like saving, searching, deleting, and reporting
class StudentManagement {
    private ArrayList<Student> students = new ArrayList<>(); // List to store students
    private Scanner scanner = new Scanner(System.in); // Scanner for user input

    // Method to save a new student
    public void saveStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.print("Enter the student id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age;
        // Loop to ensure the entered age is valid and at least 16
        while (true) {
            System.out.print("Enter the student age: ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) {
                    break; // Valid age, exit the loop
                } else {
                    System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        // Add the new student to the list
        students.add(new Student(id, name, age, email, course));
        System.out.println("Student details have been successfully saved!");
    }

    // Method to search for a student by their ID
    public void searchStudent() {
        System.out.print("Enter the student id to search: ");
        String id = scanner.nextLine();

        // Loop through the list of students to find the student with the given ID
        for (Student student : students) {
            if (student.getStudentId().equals(id)) {
                System.out.println(student); // Print student details if found
                return;
            }
        }
        System.out.println("Student with Student Id: " + id + " was not found!"); // If not found
    }

    // Method to delete a student by their ID
    public void deleteStudent() {
        System.out.print("Enter the student id to delete: ");
        String id = scanner.nextLine();

        // Loop through the list to find and delete the student with the given ID
        for (Student student : students) {
            if (student.getStudentId().equals(id)) {
                System.out.print("Are you sure you want to delete student " + id + " from the system? Yes (y) to delete: ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student); // Remove student from the list
                    System.out.println("Student with Student Id: " + id + " WAS deleted!");
                } else {
                    System.out.println("Deletion cancelled."); // If deletion is canceled
                }
                return;
            }
        }
        System.out.println("Student with Student Id: " + id + " was not found!"); // If student is not found
    }

    // Method to print a report of all students
    public void studentReport() {
        if (students.isEmpty()) { // Check if the list is empty
            System.out.println("No students found.");
        } else {
            int count = 1;
            // Loop through the list and print each student's details
            for (Student student : students) {
                System.out.println("STUDENT " + count++);
                System.out.println(student);
            }
        }
    }

    // Method to exit the application
    public void exitStudentApplication() {
        System.out.println("Exiting Student Management Application...");
        System.exit(0); // Terminate the program
    }
}


//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.