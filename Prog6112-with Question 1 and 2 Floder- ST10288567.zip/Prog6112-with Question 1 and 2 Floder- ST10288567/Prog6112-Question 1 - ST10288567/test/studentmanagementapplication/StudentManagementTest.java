/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

package studentmanagementapplication;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * JUnit test class for the StudentManagement application.
 * 
 * This class contains unit tests for the main functionalities of the 
 * StudentManagement application, such as saving, searching, deleting 
 * students, and generating reports.
 * 
 * @author Darsh Somayi
 */
public class StudentManagementTest {

    private StudentManagement sm;

    /**
     * Sets up the StudentManagement instance before each test.
     */
    @BeforeEach
    void setUp() {
        sm = new StudentManagement();
    }

    /**
     * Tests the saveStudent method by simulating user input and 
     * verifying the output.
     */
    @Test
    void testSaveStudent() {
        String input = "123\nJohn Doe\n18\njohn@example.com\nComputer Science\n";
        ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.saveStudent();
        
        String output = out.toString();
        assertTrue(output.contains("Student details have been successfully saved!"));
        assertTrue(output.contains("Enter the student id:"));
    }

    /**
     * Tests the searchStudent method when the student is found.
     */
    @Test
    void testSearchStudent_Found() {
        // Pre-populate the system with a student
        

        String input = "123\n";
        ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.searchStudent();
        
        String output = out.toString();
        assertTrue(output.contains("STUDENT ID: 123"));
        assertTrue(output.contains("STUDENT NAME: John Doe"));
    }

    /**
     * Tests the searchStudent method when the student is not found.
     */
    @Test
    void testSearchStudent_NotFound() {
        String input = "999\n";
        ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.searchStudent();
        
        String output = out.toString();
        assertTrue(output.contains("Student with Student Id: 999 was not found!"));
    }

    /**
     * Tests the deleteStudent method when the deletion is successful.
     */
    @Test
    void testDeleteStudent_Success() {
        // Pre-populate the system with a student
        
        String input = "123\ny\n";
        ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.deleteStudent();

        String output = out.toString();
        assertTrue(output.contains("Student with Student Id: 123 WAS deleted!"));
        
    }

    /**
     * Tests the deleteStudent method when the deletion is canceled.
     */
    @Test
    void testDeleteStudent_Cancel() {
        // Pre-populate the system with a student
        

        String input = "123\nn\n";
        ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.deleteStudent();

        String output = out.toString();
        assertTrue(output.contains("Deletion cancelled."));
       
    }

    /**
     * Tests the deleteStudent method when the student is not found.
     */
    @Test
    void testDeleteStudent_NotFound() {
        String input = "999\n";
        ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.deleteStudent();

        String output = out.toString();
        assertTrue(output.contains("Student with Student Id: 999 was not found!"));
    }

    /**
     * Tests the studentReport method when there are no students.
     */
    @Test
    void testStudentReport_Empty() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.studentReport();

        String output = out.toString();
        assertTrue(output.contains("No students found."));
    }

    /**
     * Tests the studentReport method when there are students.
     */
    @Test
    void testStudentReport_NotEmpty() {
        // Pre-populate the system with students
       
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        sm.studentReport();

        String output = out.toString();
        assertTrue(output.contains("STUDENT 1"));
        assertTrue(output.contains("STUDENT 2"));
        assertTrue(output.contains("STUDENT ID: 123"));
        assertTrue(output.contains("STUDENT ID: 456"));
    }
}

//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.