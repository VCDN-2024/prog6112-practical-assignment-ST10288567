/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagementsystem;

/**
 * Class representing a Part-Time Employee.
 * This class extends the abstract Employee class and provides a specific implementation for salary calculation.
 * 
 * @author Darsh Somayi
 */
public class PartTimeEmployee extends Employee {
    private int hoursWorked;   // The number of hours the part-time employee worked
    private double hourlyRate; // The rate per hour for the part-time employee

    // Constructor to initialize the part-time employee's details
    public PartTimeEmployee(int id, String name, double hourlyRate, int hoursWorked) {
        super(id, name); // Call the constructor of the superclass (Employee) to set id and name
        this.hourlyRate = hourlyRate; // Initialize hourly rate
        this.hoursWorked = hoursWorked; // Initialize hours worked
    }

    // Implementation of the abstract method calculateSalary() from the Employee class
    @Override
    public double calculateSalary() {
        // Calculate salary as the product of hours worked and the hourly rate
        return hoursWorked * hourlyRate;
    }
}



//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.