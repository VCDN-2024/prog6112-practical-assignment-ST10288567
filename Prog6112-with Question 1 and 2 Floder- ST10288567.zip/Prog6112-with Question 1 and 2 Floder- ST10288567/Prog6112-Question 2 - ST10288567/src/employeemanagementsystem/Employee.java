/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagementsystem;

/**
 * Abstract class representing an Employee.
 * This class provides a blueprint for employee objects and enforces the implementation of salary calculation.
 * 
 * @author Darsh Somayi
 */
public abstract class Employee {
    private int id;     // Unique identifier for the employee
    private String name; // Name of the employee

    // Constructor to initialize the employee's id and name
    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getter method for employee ID
    public int getId() {
        return id;
    }

    // Getter method for employee name
    public String getName() {
        return name;
    }

    // Abstract method to calculate salary, must be implemented by subclasses
    public abstract double calculateSalary();

    // Method to return a string with employee details, including calculated salary
    public String getDetails() {
        return "ID: " + id + ", Name: " + name + ", Salary: $" + calculateSalary();
    }
}





//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.