/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagementsystem;

/**
 * Class representing a Full-Time Employee.
 * This class extends the abstract Employee class and provides a specific implementation for salary calculation.
 * 
 * @author Darsh Somayi
 */
public class FullTimeEmployee extends Employee {
    private double baseSalary;   // The base salary of the full-time employee
    private double bonus;        // Any additional bonus the employee receives
    private double deductions;   // Any deductions from the employee's salary

    // Constructor to initialize the full-time employee's details
    public FullTimeEmployee(int id, String name, double baseSalary, double bonus, double deductions) {
        super(id, name); // Call the constructor of the superclass (Employee) to set id and name
        this.baseSalary = baseSalary; // Initialize base salary
        this.bonus = bonus; // Initialize bonus
        this.deductions = deductions; // Initialize deductions
    }

    // Implementation of the abstract method calculateSalary() from the Employee class
    @Override
    public double calculateSalary() {
        // Calculate salary as base salary plus bonus minus deductions
        return baseSalary + bonus - deductions;
    }
}



//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.