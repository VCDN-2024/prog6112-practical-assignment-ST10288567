/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeemanagementsystem;


/**
 *
 * @author Darsh Somayi
 */

// EmployeeManagementSystem.java

import java.util.ArrayList;
import java.util.List;

public class EmployeeManagementSystem {
    private List<Employee> employees;

    public EmployeeManagementSystem() {
        employees = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void viewEmployee(int id) {
        for (Employee emp : employees) {
            if (emp.getId() == id) {
                System.out.println(emp.getDetails());
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public void generateReport() {
        for (Employee emp : employees) {
            System.out.println(emp.getDetails());
        }
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem();
        system.addEmployee(new FullTimeEmployee(1, "John Doe", 50000, 5000, 1000));
        system.addEmployee(new PartTimeEmployee(2, "Jane Smith", 20, 120));

        system.generateReport();
    }
}


//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.