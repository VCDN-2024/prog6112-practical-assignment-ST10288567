/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package employeemanagementsystem;



import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Darsh Somayi
 */
public class EmployeeManagementSystemTest {

    @Test
    public void testAddEmployee() {
        EmployeeManagementSystem system = new EmployeeManagementSystem();
        Employee emp1 = new FullTimeEmployee(1, "John Doe", 50000, 5000, 1000);
        Employee emp2 = new PartTimeEmployee(2, "Jane Smith", 20, 120);

        system.addEmployee(emp1);
        system.addEmployee(emp2);

        
    }

    @Test
    public void testViewEmployee() {
        EmployeeManagementSystem system = new EmployeeManagementSystem();
        Employee emp1 = new FullTimeEmployee(1, "John Doe", 50000, 5000, 1000);
        system.addEmployee(emp1);

        // Capture the output to verify it
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        system.viewEmployee(1);

        // Verify the output matches the expected details
        String expectedOutput = "ID: 1, Name: John Doe, Salary: 50000, Bonus: 5000, Deductions: 1000\n";
        assertEquals(expectedOutput, outContent.toString());

        // Reset the output stream
        System.setOut(null);
    }

    @Test
    public void testGenerateReport() {
        EmployeeManagementSystem system = new EmployeeManagementSystem();
        Employee emp1 = new FullTimeEmployee(1, "John Doe", 50000, 5000, 1000);
        Employee emp2 = new PartTimeEmployee(2, "Jane Smith", 20, 120);
        system.addEmployee(emp1);
        system.addEmployee(emp2);

        // Capture the output to verify it
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        system.generateReport();

        // Verify the output matches the expected details
        String expectedOutput = """
                                ID: 1, Name: John Doe, Salary: 50000, Bonus: 5000, Deductions: 1000
                                ID: 2, Name: Jane Smith, Hourly Rate: 20, Hours Worked: 120
                                """;
        assertEquals(expectedOutput, outContent.toString());

        // Reset the output stream
        System.setOut(null);
    }
}



//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.