/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package employeemanagementsystem;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for FullTimeEmployee.
 * This class contains unit tests to verify the correct calculation of the salary
 * for a full-time employee.
 * 
 * The salary calculation typically includes base salary, bonus, and any other allowances.
 */
public class FullTimeEmployeeTest {

    /**
     * Test of the calculateSalary method in the FullTimeEmployee class.
     * 
     * This test case verifies that the calculateSalary method returns the correct
     * salary value when provided with base salary, bonus, and allowance.
     */
    @Test
    public void testCalculateSalary() {
        // Arrange: Create a FullTimeEmployee object with predefined values
        FullTimeEmployee emp = new FullTimeEmployee(1, "John Doe", 50000, 5000, 1000);
        
        // Expected salary calculation: base salary + bonus + allowance
        double expectedSalary = 54000.0;

        // Act: Call the method under test
        double actualSalary = emp.calculateSalary();

        // Assert: Verify that the actual salary matches the expected salary
        assertEquals(expectedSalary, actualSalary, 0.001);
    }
}


//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.