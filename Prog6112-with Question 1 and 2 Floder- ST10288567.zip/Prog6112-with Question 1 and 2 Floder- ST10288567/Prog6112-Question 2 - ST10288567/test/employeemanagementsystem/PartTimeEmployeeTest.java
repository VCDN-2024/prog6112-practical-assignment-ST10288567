/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package employeemanagementsystem;

import org.junit.Test;
import static org.junit.Assert.*;

public class PartTimeEmployeeTest {

    @Test
    public void testCalculateSalary() {
        // Setup: Create a PartTimeEmployee with specific attributes
        PartTimeEmployee emp = new PartTimeEmployee(2, "Jane Smith", 20, 120);

        // Execution: Calculate the salary
        double actualSalary = emp.calculateSalary();

        // Assertion: Check if the calculated salary matches the expected salary
        assertEquals(2400.0, actualSalary, 0.001);
    }
}


//Reference List

//Date: 03 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.